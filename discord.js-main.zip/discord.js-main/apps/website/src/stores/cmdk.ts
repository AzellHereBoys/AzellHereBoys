import { atom } from 'jotai';

export const isCmdKOpenAtom = atom(false);
