export { default } from '~/app/not-found';
