/* eslint-disable @typescript-eslint/no-empty-interface,tsdoc/syntax */
/**
 * @block
 * @inline test
 * @modifier
 */
interface CustomTagsTestInterface {}
